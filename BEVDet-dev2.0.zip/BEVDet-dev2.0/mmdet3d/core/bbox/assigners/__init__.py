# Copyright (c) OpenMMLab. All rights reserved.
from mmdet.core.bbox import AssignResult, BaseAssigner, MaxIoUAssigner

__all__ = ['BaseAssigner', 'MaxIoUAssigner', 'AssignResult']
