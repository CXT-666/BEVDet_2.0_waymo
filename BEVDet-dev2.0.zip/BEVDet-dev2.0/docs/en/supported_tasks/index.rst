.. toctree::
   :maxdepth: 2

   lidar_det3d.md
   vision_det3d.md
   lidar_sem_seg3d.md
